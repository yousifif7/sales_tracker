import './bootstrap';

document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('[data-rich-editor]').forEach((root) => {
        const surface = root.querySelector('.rich-surface');
        const input = root.querySelector('textarea');
        if (! surface || ! input) {
            return;
        }

        const sync = () => {
            input.value = surface.innerHTML.trim() === '<br>' ? '' : surface.innerHTML;
        };

        root.querySelectorAll('[data-cmd]').forEach((button) => {
            button.addEventListener('click', (event) => {
                event.preventDefault();
                const command = button.getAttribute('data-cmd');
                surface.focus();

                if (command === 'createLink') {
                    const url = window.prompt('Enter URL (https://...)');
                    if (! url) {
                        return;
                    }
                    const normalized = /^(https?:\/\/|mailto:)/i.test(url) ? url : `https://${url}`;
                    document.execCommand('createLink', false, normalized);
                } else {
                    document.execCommand(command, false, null);
                }

                sync();
            });
        });

        surface.addEventListener('input', sync);
        surface.addEventListener('blur', sync);

        const form = root.closest('form');
        form?.addEventListener('submit', sync);

        sync();
    });
});
